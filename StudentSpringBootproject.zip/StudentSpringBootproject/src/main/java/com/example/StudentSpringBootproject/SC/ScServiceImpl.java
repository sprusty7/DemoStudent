package com.example.StudentSpringBootproject.SC;

import java.util.List;

import org.springframework.stereotype.Service;


@Service
public class ScServiceImpl implements ScService {

	
	
	private ScRepository scRepository;
	
	
	
	
	public ScServiceImpl(ScRepository scRepository) {
		super();
		this.scRepository = scRepository;
	}

	

	@Override
	public List<Sc> getAllScs() {
		return scRepository.findAll();
	}

	@Override
	public Sc saveSc(Sc sc) {
		return scRepository.save(sc);
	}

	@Override
	public Sc getScById(Long classid) {
		return scRepository.findById(classid).get();
	}

	@Override
	public Sc updateSc(Sc sc) {
		return scRepository.save(sc);
	}

	@Override
	public void deleteScById(Long classid) {
		scRepository.deleteById(classid);		
		
	}

}
