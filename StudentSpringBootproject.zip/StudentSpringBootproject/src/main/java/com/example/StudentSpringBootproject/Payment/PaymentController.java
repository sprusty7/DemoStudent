package com.example.StudentSpringBootproject.Payment;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;





@Controller
public class PaymentController 
{
	private PaymentService paymentService;

	public PaymentController(PaymentService paymentService) {
		super();
		this.paymentService = paymentService;
	}
	
	@GetMapping("/payments")
	public String listPayments(Model model) {
		model.addAttribute("payments", paymentService.getAllPayments());
		return "payments";
	}

	
	
	@GetMapping("/payments/new")
	public String createPaymentForm(Model model) {
		
		
		Payment payment = new Payment();
		model.addAttribute("payments", payment);
		return "create_payment";
		
	}
	@PostMapping("/payments")
	public String savePayment(@ModelAttribute("payment") Payment payment) {
		paymentService.savePayment(payment);
		return "redirect:/payments";
	}
	@GetMapping("/payments1/new")
	public String createPayment1Form(Model model) {
		
		
		Payment payment = new Payment();
		model.addAttribute("payments1", payment);
		return "create_payment";
		
	}
	@PostMapping("/payments1")
	public String savePayment1(@ModelAttribute("payment") Payment payment) {
		paymentService.savePayment(payment);
		return "redirect:/payments1";
	}
	
}
