package com.example.StudentSpringBootproject.SC;

import java.util.List;



public interface ScService 
{
List<Sc> getAllScs();
	
	Sc saveSc(Sc sc);
	
	Sc getScById(Long classid);
	
	Sc updateSc(Sc sc);
	
	void deleteScById(Long classid);


}
