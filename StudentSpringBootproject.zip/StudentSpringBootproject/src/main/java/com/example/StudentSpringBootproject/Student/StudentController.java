package com.example.StudentSpringBootproject.Student;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;





@Controller
public class StudentController 
{
	
	
	
	private StudentService studentService;
	public StudentController(StudentService studentService)
	{
		super();
		this.studentService= studentService;
		
	}

	@GetMapping("/students")
	public String listStudents(Model model)
	{
		model.addAttribute("students", studentService.getAllStudents());
		return "students";
		
	}
	
	@GetMapping("/students/new")
	public String createStudentForm(Model model) {
		
		// create student object to hold student form data
		Student student = new Student();
		model.addAttribute("students", student);
		return "create_student";
		
	}
	
	@PostMapping("/students")
	public String saveStudent(@ModelAttribute("student") Student student) {
		studentService.saveStudent(student);
		return "redirect:/students";
	}
	
	@GetMapping("/students/edit/{registrationid}")
	public String editStudentForm(@PathVariable Long registrationid, Model model) {
		model.addAttribute("student", studentService.getStudentById(registrationid));
		return "approve";
	}
	
	
	@PostMapping("/students/{registrationid}")
	public String updateStudent(@PathVariable Long registrationid,
			@ModelAttribute("student") Student student,
			Model model) {
		Student existingStudent = studentService.getStudentById(registrationid);
//		existingStudent.setRegistrationid(registrationid);
//		existingStudent.setFirstname(student.getFirstname());
//		existingStudent.setCourseid(student.getCourseid());
//		existingStudent.setLastname(student.getLastname());
//		existingStudent.setDob(student.getDob());
//		existingStudent.setMobilenumber(student.getMobilenumber());
//		existingStudent.setEmailid(student.getEmailid());
//		existingStudent.setCourseapplied(student.getCourseapplied());
//		existingStudent.setLastcoursestudied(student.getLastcoursestudied());
//		existingStudent.setDateofpass(student.getDateofpass());
//		existingStudent.setAveragemarks(student.getAveragemarks());
//		existingStudent.setStatus(student.getStatus());
		existingStudent.setStatus("Approved");
		
		
		studentService.updateStudent(existingStudent);
		return "redirect:/students";	
	}
	
//	@GetMapping("/students/edit1/{registrationid}")
//	public String editStudentForm1(@PathVariable Long registrationid, Model model) {
//		model.addAttribute("student", studentService.getStudentById1(registrationid));
//		return "edit_student";
//	}
//	@PostMapping("/students/{registrationid}")
//	public String updateStudent1(@PathVariable Long registrationid,
//			@ModelAttribute("student") Student student,
//			Model model) {
//		Student existingStudent1 = studentService.getStudentById1(registrationid);
//		existingStudent1.setRegistrationid(registrationid);
//		existingStudent1.setFirstname(student.getFirstname());
//		existingStudent1.setCourseid(student.getCourseid());
//		existingStudent1.setLastname(student.getLastname());
//		existingStudent1.setDob(student.getDob());
//		existingStudent1.setMobilenumber(student.getMobilenumber());
//		existingStudent1.setEmailid(student.getEmailid());
//		existingStudent1.setCourseapplied(student.getCourseapplied());
//		existingStudent1.setLastcoursestudied(student.getLastcoursestudied());
//		existingStudent1.setDateofpass(student.getDateofpass());
//		existingStudent1.setAveragemarks(student.getAveragemarks());
//		existingStudent1.setStatus(student.getStatus());
//	
//		
//		
//		studentService.updateStudent1(existingStudent1);
//		return "redirect:/students";	
//	}
//	
//	
//	
	
		@GetMapping("/students/{registrationid}")
		public String deleteStudent(@PathVariable Long registrationid) {
			studentService.deleteStudentById(registrationid);
			return "redirect:/students";
		}
	
}
