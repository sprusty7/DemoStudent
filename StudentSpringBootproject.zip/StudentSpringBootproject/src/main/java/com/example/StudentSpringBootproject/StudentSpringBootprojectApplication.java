package com.example.StudentSpringBootproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSpringBootprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentSpringBootprojectApplication.class, args);
	}

}
